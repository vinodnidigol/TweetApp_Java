package com.tweetapp.model;

public class Constants {
    private Constants() {
    }

    public static final  String USERNOTFOUND="User Not Found";

    public static final String INVALIDTWEETID="Provide valid Tweet Id.";

    public static final  String INVALIDTWEETIDORUSERNAME="User Not Found or No Post";
}
